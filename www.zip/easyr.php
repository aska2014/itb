<?php
`php artisan drop:all`;
`php artisan wmigrate`;
`php artisan db:seed`;
