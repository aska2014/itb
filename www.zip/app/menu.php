<?php

return Menu::factory(array(



    'mission_vision'        => 'mission-vision.html',
    'our_values'            => 'our-values.html',
    'our_promise'           => 'our-promise.html',
    'services'              => 'services.html',
    'distribution'          => 'distribution.html',
    'future_outlook'        => 'future-outlook.html',

    'home'                  => '/',
    'about_us'              => 'about-us.html',
    'videos'                => 'videos.html',
    'our_products'          => 'our-products.html',
    'special_offers'        => 'special-offers.html',
    'partners'              => 'partners.html',
    'international'         => 'international.html',
    'contact_us'            => 'contact-us.html',
    'our_team'              => 'our-team.html',
    'download'              => 'download.html',
    'policies'              => 'policies.html',

    'prospect_catalogue'    => 'prospect-catalogue.html',
    'spire_parts'           => 'spire-parts.html',


));