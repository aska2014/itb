<?php

return array(

    'latest'         => 'New products',
    'featured'       => 'Featured products',
    'specials'       => 'Specials',
    'related'        => 'Related products',

    'videos'         => 'Videos',

    'our_products'   => 'Our products',

    'buy'            => 'Buy this product',

    'description'    => 'Description',
    'specifications' => 'Specifications',

    'send'           => 'Send',

    'egypt'          => 'Egypt',
    'Switzerland'    => 'Switzerland',
    'england'        => 'England',

    'connect'        => 'Connect with us',

    'copyrights'     => 'All Rights Reserved I.T.B',

    'design_by'      => 'DESIGN BY SWAQNY',

    'email'          => 'Email',
    'mobile'         => 'Mobile',
    'name'           => 'Name',
    'message'        => 'Message',

    'currency'       => 'EGP'
);