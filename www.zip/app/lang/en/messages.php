<?php

return array(
    'order_sent' => 'Your order has been successfully sent.'
);