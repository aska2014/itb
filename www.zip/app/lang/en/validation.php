<?php

return array(
    'email' => 'Please enter a valid email address.',
    'mobile' => 'Please enter your mobile number'
);