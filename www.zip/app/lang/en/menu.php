<?php

return array(

    'mission_vision'      => 'Mission & Vision',
    'our_values'          => 'Our Values',
    'our_promise'         => 'Our Promise',
    'services'            => 'Services',
    'distribution'        => 'Distribution',
    'future_outlook'      => 'Future Outlook',

    'home'                => 'Home',
    'about_us'            => 'About Us',
    'videos'              => 'Videos',
    'our_products'        => 'Our products',
    'special_offers'      => 'Special offers',
    'partners'            => 'Partners',
    'international'       => 'International',
    'contact_us'          => 'Contact us',
    'our_team'            => 'Our team',
    'download'            => 'Download',
    'policies'            => 'Policies',

    'prospect_catalogue'  => 'Prospect / Catalogue',
    'spire_parts'         => 'Spire Parts',

    'categories'          => 'Categories',

    'location'            => 'Location',
    'contact_form'        => 'Contact Form',
    'sales_marketing'     => 'Sales Marketing',

);