<?php

return array(
    'order_sent' => 'لقد تم إرسال طلبك بنجاح.'
);