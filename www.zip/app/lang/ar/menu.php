<?php

return array(

    'mission_vision'      => 'مهمتنا و رؤيتنا',
    'our_values'          => 'قيمنا',
    'our_promise'         => 'وعدنا',
    'services'            => 'خدماتنا',
    'distribution'        => 'التوزيع',
    'future_outlook'      => 'النظرة المستقبلية',

    'home'                => 'الرئيسيـــة',
    'about_us'            => 'نبذة عــن',
    'videos'              => 'فيديو',
    'our_products'        => 'منتجـــات',
    'special_offers'      => 'عروض خـــاصة',
    'partners'            => 'شركــاء',
    'international'       => 'دولى',
    'contact_us'          => 'اتصل بـــنا',
    'our_team'            => 'فريق العمــل',
    'download'            => 'تحميـــل',
    'policies'            => 'السياسات',


    'prospect_catalogue'  => 'احتمال / الكاتالوج',
    'spire_parts'         => 'قطع مستدقة',

    'categories'          => 'الفئات',

    'location'            => 'موقع',
    'contact_form'        => 'أتصل بنا',
    'sales_marketing'     => 'المبيعات والتسويق',

);