<?php

return array(

    'latest'         => 'منتجات جديدة',
    'featured'       => 'منتجات مميزة',
    'specials'       => 'عروض خاصة',
    'related'        => 'المنتجات ذات صلة',

    'videos'         => 'الفيديوهات',

    'our_products'   => 'منتجاتنا',

    'buy'            => 'لشراء هذا المنتج',

    'description'    => 'الوصف',
    'specifications' => 'المواصفات',

    'send'           => 'إرسال',

    'egypt'          => 'مصر',
    'Switzerland'    => 'سويسرا',
    'england'        => 'انجلترا',

    'connect'        => 'تابعنا على',

    'copyrights'     => 'جميع الحقوق محفوظة لشركة I.T.B',


    'design_by'      => 'DESIGN BY SWAQNY',

    'email'          => 'الإيميل',
    'mobile'         => 'رقم الموبيل',
    'name'           => 'الأسم',
    'message'        => 'الرسالة',


    'currency'       => 'ج.م'
);