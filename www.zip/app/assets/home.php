<?php

Asset::add('demo', 'css/demo.css');
Asset::add('elastislide', 'css/elastislide.css');
Asset::add('custom', 'css/custom.css');
Asset::add('modernizr', 'js/modernizr.custom.17475.js');