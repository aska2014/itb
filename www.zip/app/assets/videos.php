<?php

Asset::add('mootools', 'js/mootools.js');
Asset::add('swfobject', 'js/swfobject.js');
Asset::add('videobox', 'js/videobox.js');
Asset::add('videobox', 'css/videobox.css');
