<?php

Asset::add('bootstrap', 'css/bootstrap.min.css');
Asset::add('style00', 'css/style00.css');
Asset::add('style', 'css/style.css');
Asset::add('style2', 'css/style2.css');

Asset::add('jquery', 'js/jquery.js');