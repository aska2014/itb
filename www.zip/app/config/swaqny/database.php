<?php

return array(

    'mysql' => array(
        'driver'    => 'mysql',
        'host'      => 'localhost',
        'database'  => 'haron_itb',
        'username'  => 'haron_kareem',
        'password'  => 'NIUAN23ewaA',
        'charset'   => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix'    => '',
    ),

);