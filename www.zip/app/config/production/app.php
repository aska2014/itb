<?php

return array(
    'debug' => false
);