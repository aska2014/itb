<?php

return array(

    'mysql' => array(
        'driver'    => 'mysql',
        'host'      => 'localhost',
        'database'  => 'itbswiss_laravel',
        'username'  => 'kareem',
        'password'  => 'AOS@EWKAzzx',
        'charset'   => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix'    => '',
    ),

);