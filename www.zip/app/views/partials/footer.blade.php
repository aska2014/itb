<div id="footer11">
    <div id="bk-footer">
        <div id="blockfooter11">
            <span>{{ trans('words.egypt') }}</span>
            <img src="{{ lan_asset('img/1377442371_Flag_of_Egypt.png') }}">
            <p>
                Office Address : El Zahra’a Street No.8 – Benha – Al Qualubiya.
                Stores Address : Tant El-Gazira – Toukh – Al-Qualubiya
                Tel.: +2 013 249 26 17
                Mobile: +2 012 005 331 3
                Email : info@itbswiss.com
            </p>
        </div>
        <div id="blockfooter11">
            <span>{{ trans('words.switzerland') }}</span>
            <img src="{{ lan_asset('img/1377442341_Flag_of_Switzerland.png') }}">
            <p>
                Office Address : El Zahra’a Street No.8 – Benha – Al Qualubiya.
                Stores Address : Tant El-Gazira – Toukh – Al-Qualubiya
                Tel.: +2 013 249 26 17
                Mobile: +2 012 005 331 3
                Email : info@itbswiss.com
            </p>
        </div>
        <div id="blockfooter11">
            <span>{{ trans('words.germany') }}</span>
            <img src="{{ lan_asset('img/1377442347_Flag_of_United_Kingdom.png') }}">
            <p>
                Office Address : El Zahra’a Street No.8 – Benha – Al Qualubiya.
                Stores Address : Tant El-Gazira – Toukh – Al-Qualubiya
                Tel.: +2 013 249 26 17
                Mobile: +2 012 005 331 3
                Email : info@itbswiss.com
            </p>
        </div>
        <div id="blockfooter22">
            <span>{{ trans('words.connect') }}</span></br></br></br>
            <div id="followfooter">
                <a href="#"><img src="{{ lan_asset('img/pic-fac.png') }}"><span>facbook</span></a></br>
                <a href="#"><img src="{{ lan_asset('img/pic-twiit.png') }}"><span>Twitter</span></a></br>
                <a href="#"><img src="{{ lan_asset('img/pic-rss.png') }}"><span>RSS</span></a></br>
                <a href="#"><img src="{{ lan_asset('img/pic-you.png') }}"><span>You Tub</span></a>
            </div>
        </div>
        <span class="namecompany">{{ trans('words.design_by') }}</span>
    </div>
    <div id="footer22">
        <span>{{ trans('words.copyrights') }}</span>
    </div>
</div>