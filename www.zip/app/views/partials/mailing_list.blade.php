<div id="malinglist">
    <div id="picmaling"></div>
    <input type="email" id="email" name="email" class="txt">
    <div id="ptnmail"><a href="#"><span>Send</span></a></div>
</div>