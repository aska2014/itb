<div id="homepage">

    @include('partials.left')

    <div id="right">
        <div id="headright"><span>Partener</span></div>
        <div id="rightpartener">
            <div class="blockpartener11">
                <div class="picpartener">
                    <img src="{{ lan_asset('img/logopartener.png') }}">
                </div>
                <h3>I.T.T</h3>
                <p>
                    <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> is a West Germanic language that was first spoken in early medieval England and is now the most widely used language in the world.[4] It is spoken as a first language by the majority populations of several sovereign states, including the United Kingdom, the United States, Canada, Australia, Ireland, New Zealand and a number of Caribbean nations. It is the third-most-common native language in the world, after Mandarin Chinese and Spanish.[5] It is widely learned as a second language and is an official language of the European Union, many Commonwealth countries and the United Nations, as well as in many world organisations
                </p>
            </div>
            <div class="blockpartener11">
                <div class="picpartener">
                    <img src="{{ lan_asset('img/logopartener.png') }}">
                </div>
                <h3>I.T.T</h3>
                <p>
                    <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> is a West Germanic language that was first spoken in early medieval England and is now the most widely used language in the world.[4] It is spoken as a first language by the majority populations of several sovereign states, including the United Kingdom, the United States, Canada, Australia, Ireland, New Zealand and a number of Caribbean nations. It is the third-most-common native language in the world, after Mandarin Chinese and Spanish.[5] It is widely learned as a second language and is an official language of the European Union, many Commonwealth countries and the United Nations, as well as in many world organisations
                </p>
            </div>
            <div class="blockpartener11">
                <div class="picpartener">
                    <img src="{{ lan_asset('img/logopartener.png') }}">
                </div>
                <h3>I.T.T</h3>
                <p>
                    <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> is a West Germanic language that was first spoken in early medieval England and is now the most widely used language in the world.[4] It is spoken as a first language by the majority populations of several sovereign states, including the United Kingdom, the United States, Canada, Australia, Ireland, New Zealand and a number of Caribbean nations. It is the third-most-common native language in the world, after Mandarin Chinese and Spanish.[5] It is widely learned as a second language and is an official language of the European Union, many Commonwealth countries and the United Nations, as well as in many world organisations
                </p>
            </div>
            <div class="blockpartener11">
                <div class="picpartener">
                    <img src="{{ lan_asset('img/logopartener.png') }}">
                </div>
                <h3>I.T.T</h3>
                <p>
                    <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> is a West Germanic language that was first spoken in early medieval England and is now the most widely used language in the world.[4] It is spoken as a first language by the majority populations of several sovereign states, including the United Kingdom, the United States, Canada, Australia, Ireland, New Zealand and a number of Caribbean nations. It is the third-most-common native language in the world, after Mandarin Chinese and Spanish.[5] It is widely learned as a second language and is an official language of the European Union, many Commonwealth countries and the United Nations, as well as in many world organisations
                </p>
            </div>
        </div>
    </div>
</div>
