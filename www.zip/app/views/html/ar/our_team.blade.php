<div id="homepage">

    @include('partials.left')

    <div id="right">
        <div id="headrightaboutus"><span>فريــق العمل</span></div>
        <div id="pageourteam">
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
            <div id="blockourteam">
                <img src="{{ lan_asset('img/photoourdream.png') }}">
                <h6>Mohamed Mohamed</h6>
                <span>Director-General</span>
            </div>
        </div>
    </div>
</div>
