<div id="homepage">

    <?php
    $menuItems = menu_items(

        'prospect_catalogue',
        'spire_parts',
        'special_offers'
    );
    ?>

    @include('partials.left', compact('menuItems'))

    <div id="right">
        <div id="headrightaboutus"><span>Spire parts</span></div>
        <div id="pagedowenload">
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
            <div class="book11">
                <a href="#"><img src="{{ lan_asset('img/pic-book.png') }}"></a>
                <a href="#"><h4>Dowenload</h4></a><br>
                <a href="#"><h5>Viwe</h5></a>
            </div>
        </div>

    </div>
</div>
