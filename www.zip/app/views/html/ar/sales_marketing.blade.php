<div id="homepage">
    <?php
    $menuItems = menu_items(

        'location',
        'contact_form',
        'sales_marketing'
    );
    ?>

    @include('partials.left', compact('menuItems'))

    <div id="right">
        <div id="headrightaboutus"><span>نبذه عـــن</span></div>
        <p id="textaboutas">
            <span class="texttitel">أعلى جودة وبأسعار معقولة</span></br></br>
            تحت هذا الشعار، <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> تطوير وتسويق المنتجات للمنزل، شريحة الحرفيين، حديقة والترفيه. جودة عالية على الدوام من المنتجات، يرافقه سياسات تسعير ملائمة للعملاء، تهدف إلى تحقيق الاستقرار، هي عوامل النجاح الرئيسية في وجود الشركة. رد فعل أسرع وأكثر مرونة وابتكارا من الآخرين احترام مبادئ سياسة المنتج ..</br></br>
            <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> تطوير وتسويق المنتجات للمنزل، شريحة الحرفيين، حديقة والترفيه. جودة عالية على الدوام من المنتجات، يرافقه سياسات تسعير ملائمة للعملاء، تهدف إلى تحقيق الاستقرار، هي عوامل النجاح الرئيسية في وجود الشركة. رد فعل أسرع وأكثر مرونة وابتكارا من الآخرين احترام مبادئ سياسة المنتج ..</br></br>

            <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> تطوير وتسويق المنتجات للمنزل، شريحة الحرفيين، حديقة والترفيه. جودة عالية على الدوام من المنتجات، يرافقه سياسات تسعير ملائمة للعملاء، تهدف إلى تحقيق الاستقرار، هي عوامل النجاح الرئيسية في وجود الشركة. رد فعل أسرع وأكثر مرونة وابتكارا من الآخرين احترام مبادئ سياسة المنتج ..</br></br>

            <span id="logoabout00"> <strong>I<span class="point">.</span>T<span class="point">.</span>B</strong> <strong class="ttt">Swiss</strong></span> تطوير وتسويق المنتجات للمنزل، شريحة الحرفيين، حديقة والترفيه. جودة عالية على الدوام من المنتجات، يرافقه سياسات تسعير ملائمة للعملاء، تهدف إلى تحقيق الاستقرار، هي عوامل النجاح الرئيسية في وجود الشركة. رد فعل أسرع وأكثر مرونة وابتكارا من الآخرين احترام مبادئ سياسة المنتج ..</br></br>
        </p>
    </div>
</div>
