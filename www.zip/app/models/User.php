<?php

class User extends Kareem3d\Membership\User {
}