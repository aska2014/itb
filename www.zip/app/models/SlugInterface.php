<?php

interface SlugInterface {

    /**
     * @return string
     */
    public function getSlug();

}